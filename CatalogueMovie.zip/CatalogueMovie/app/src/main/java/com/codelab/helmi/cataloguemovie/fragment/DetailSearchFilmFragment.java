package com.codelab.helmi.cataloguemovie.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.codelab.helmi.cataloguemovie.R;
import com.codelab.helmi.cataloguemovie.model.SearchFilmModel;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * A simple {@link Fragment} subclass.
 */
public class DetailSearchFilmFragment extends Fragment {

    View view;
    public static String EXTRA_DETAIL_FILM = "extra_detail_film";
    Bundle bundle;
    SearchFilmModel resultsItem;
    @BindView(R.id.tv_detail_judul) TextView tvDetailJudul;
    @BindView(R.id.tv_detail_release_date) TextView tvDetailReleaseDate;
    @BindView(R.id.tv_detail_overview) TextView tvDetailOverview;
    @BindView(R.id.iv_detail_film) ImageView ivDetailFilm;

    public DetailSearchFilmFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_detail_search_film, container, false);
        ButterKnife.bind(this,view);
        tampilDataDetail();

        return view;
    }

    private void tampilDataDetail() {
        bundle = this.getArguments();
        resultsItem = bundle.getParcelable(EXTRA_DETAIL_FILM);
        tvDetailJudul.setText(resultsItem.getOriginalTitle());
        tvDetailOverview.setText(resultsItem.getOverview());
        tvDetailReleaseDate.setText(resultsItem.getReleaseDate());
        Glide.with(this).load("http://image.tmdb.org/t/p/w500/" + resultsItem.getPosterPath()).into(ivDetailFilm);

    }
}
