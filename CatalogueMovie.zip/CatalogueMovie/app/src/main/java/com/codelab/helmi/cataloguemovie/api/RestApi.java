package com.codelab.helmi.cataloguemovie.api;


import com.codelab.helmi.cataloguemovie.BuildConfig;
import com.codelab.helmi.cataloguemovie.model.MoviesResponseModel;
import com.codelab.helmi.cataloguemovie.model.SearchFilmResponseModel;
import com.codelab.helmi.cataloguemovie.model.TvResponseModel;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RestApi {

    String API_KEY = BuildConfig.API_KEY;

    @GET("search/movie?api_key="+API_KEY)
    Call<SearchFilmResponseModel> searchFilmData(@Query("query") String query, @Query("language") String language);

    @GET("discover/movie?api_key="+API_KEY)
    Call<MoviesResponseModel> getMovies(@Query("language") String language);

    @GET("discover/tv?api_key="+API_KEY)
    Call<TvResponseModel> getTvShows(@Query("language") String language);
}
