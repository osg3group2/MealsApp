package com.codelab.helmi.cataloguemovie.fragment;


import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.codelab.helmi.cataloguemovie.R;
import com.codelab.helmi.cataloguemovie.adapter.MoviesRecyclerAdapter;
import com.codelab.helmi.cataloguemovie.api.RestApi;
import com.codelab.helmi.cataloguemovie.api.RestServer;
import com.codelab.helmi.cataloguemovie.model.MoviesModel;
import com.codelab.helmi.cataloguemovie.model.MoviesResponseModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class MoviesFragment extends Fragment {

    View view;
    @BindView(R.id.progress_circular)
    ProgressBar progressCircular;

    private MoviesRecyclerAdapter mAdapter;
    private RecyclerView.LayoutManager mManager;

    RestApi api = RestServer.getClient().create(RestApi.class);

    ArrayList<MoviesModel> mList = new ArrayList<>();

    private static String KEY_MOVIES = "movies";

    @BindView(R.id.recyclerTemp2)
    RecyclerView mRecycler;

    Unbinder unbinder;

    public MoviesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.recycler_content_main, container, false);
        unbinder = ButterKnife.bind(this, view);

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView();
        if (savedInstanceState == null) {
            progressCircular.setVisibility(View.VISIBLE);
            loadData();
        } else {
            ArrayList<MoviesModel> mList2 = new ArrayList<>();
            mList2 = savedInstanceState.getParcelableArrayList(KEY_MOVIES);
            mList.addAll(mList2);
            mAdapter.notifyDataSetChanged();
        }

    }

    private void loadData() {
        Call<MoviesResponseModel> getData = api.getMovies(getResources().getString(R.string.language));
        getData.enqueue(new Callback<MoviesResponseModel>() {
            @Override
            public void onResponse(Call<MoviesResponseModel> call, Response<MoviesResponseModel> response) {
                try {
                    if (response.isSuccessful()) {
                        mList.addAll(response.body().getResults());
                        mAdapter.notifyDataSetChanged();
//                        mAdapter = new MoviesRecyclerAdapter(mList, getFragmentManager(), getActivity());
//                        mRecycler.setAdapter(mAdapter);
                        progressCircular.setVisibility(View.GONE);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    progressCircular.setVisibility(View.GONE);
                    Toast.makeText(getActivity(), "Data Gagal Dimuat !", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<MoviesResponseModel> call, Throwable t) {
                t.printStackTrace();
                progressCircular.setVisibility(View.GONE);
            }
        });
    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putParcelableArrayList(KEY_MOVIES, mList);
        super.onSaveInstanceState(outState);
    }

    private void initView() {
        mManager = new LinearLayoutManager(getContext());
        mRecycler.setHasFixedSize(true);
        mRecycler.setLayoutManager(mManager);
        mAdapter = new MoviesRecyclerAdapter(mList, getFragmentManager(), getActivity());
        mRecycler.setAdapter(mAdapter);

    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }
}
