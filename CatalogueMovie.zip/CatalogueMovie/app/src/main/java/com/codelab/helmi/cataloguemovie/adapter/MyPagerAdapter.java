package com.codelab.helmi.cataloguemovie.adapter;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;
import android.view.ViewGroup;

import com.codelab.helmi.cataloguemovie.R;
import com.codelab.helmi.cataloguemovie.fragment.MoviesFragment;
import com.codelab.helmi.cataloguemovie.fragment.TvShowsFragment;

public class MyPagerAdapter extends FragmentStatePagerAdapter {

    private Context context;

    public MyPagerAdapter(FragmentManager fm, Context context) {
        super(fm);
        this.context = context;
    }

    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                 return new MoviesFragment();
            case 1:
                return new TvShowsFragment();
        }
        return null;
    }

    @Override
    public int getCount() {
        return 2;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        switch (position) {
            case 0:
                return context.getResources().getString(R.string.movies);
            case 1:
                return context.getResources().getString(R.string.tv);
        }
        return null;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        // TODO Auto-generated method stub
    }
}