package com.codelab.helmi.cataloguemovie.fragment;


import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.codelab.helmi.cataloguemovie.R;
import com.codelab.helmi.cataloguemovie.adapter.SearchFilmRecyclerAdapter;
import com.codelab.helmi.cataloguemovie.api.RestApi;
import com.codelab.helmi.cataloguemovie.api.RestServer;
import com.codelab.helmi.cataloguemovie.model.SearchFilmModel;
import com.codelab.helmi.cataloguemovie.model.SearchFilmResponseModel;
import com.codelab.helmi.cataloguemovie.model.TvModel;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * A simple {@link Fragment} subclass.
 */
public class SearchFilmFragment extends Fragment implements View.OnClickListener, SearchView.OnQueryTextListener {

    View view;
    private SearchFilmRecyclerAdapter mAdapter;
    private RecyclerView.LayoutManager mManager;

    private static String KEY_MOVIES = "movies";

    RestApi api = RestServer.getClient().create(RestApi.class);

    ArrayList<SearchFilmModel> mList = new ArrayList<>();

    @BindView(R.id.recyclerTemp) RecyclerView mRecycler;
    @BindView(R.id.search_view) SearchView searchView;

    Unbinder unbinder;


    public SearchFilmFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.recycler_content, container, false);
        unbinder = ButterKnife.bind(this, view);
        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initView();

        if (savedInstanceState == null) {
            loadData("avenger");
        } else {
            ArrayList<SearchFilmModel> mList2 = new ArrayList<>();
            mList2 = savedInstanceState.getParcelableArrayList(KEY_MOVIES);
            mList.addAll(mList2);
            mAdapter.notifyDataSetChanged();
        }

    }

    private void initView() {
        mManager = new LinearLayoutManager(getActivity());
        mRecycler.setHasFixedSize(true);
        mRecycler.setLayoutManager(mManager);
        searchView.setOnClickListener(this);
        searchView.setOnQueryTextListener(this);
        mAdapter = new SearchFilmRecyclerAdapter(mList, getFragmentManager(), getActivity());
        mRecycler.setAdapter(mAdapter);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.search_view:
                searchView.setIconified(false);
                break;
        }

    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        loadData(query);
        return true;
    }

    @Override
    public boolean onQueryTextChange(String newText) {
        return false;
    }

    public void loadData(String query) {

        Call<SearchFilmResponseModel> getData = api.searchFilmData(query,getResources().getString(R.string.language));
        getData.enqueue(new Callback<SearchFilmResponseModel>() {
            @Override
            public void onResponse(Call<SearchFilmResponseModel> call, Response<SearchFilmResponseModel> response) {
                try {
                    if (response.isSuccessful()) {
                        mList.addAll(response.body().getResults());
                        mAdapter.notifyDataSetChanged();

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<SearchFilmResponseModel> call, Throwable t) {
                t.printStackTrace();
            }
        });

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putParcelableArrayList(KEY_MOVIES, mList);
        super.onSaveInstanceState(outState);
    }
}
