package com.codelab.helmi.cataloguemovie.adapter;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.codelab.helmi.cataloguemovie.R;
import com.codelab.helmi.cataloguemovie.fragment.DetailSearchFilmFragment;
import com.codelab.helmi.cataloguemovie.model.SearchFilmModel;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class SearchFilmRecyclerAdapter extends RecyclerView.Adapter<SearchFilmRecyclerAdapter.MyHolder> {

    private ArrayList<SearchFilmModel> mList;
    private FragmentManager fragmentManager;
    private Context context;

    public SearchFilmRecyclerAdapter(ArrayList<SearchFilmModel> mList, FragmentManager fragmentManager, Context context) {
            this.fragmentManager = fragmentManager;
            this.mList = mList;
            this.context = context;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View layout = LayoutInflater.from(parent.getContext()).inflate(R.layout.fragment_search_film,parent,false);
        MyHolder holder = new MyHolder(layout);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, final int position) {
        holder.judul.setText(mList.get(position).getOriginalTitle());
        holder.overview.setText(mList.get(position).getOverview());
        holder.overview.setMaxLines(1);
        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        DateFormat formatter = new SimpleDateFormat("EEEE, MMM dd, yyyy", Locale.US);

        try {
            Date dt1 = format1.parse(mList.get(position).getReleaseDate());
            String finalDay = formatter.format(dt1);
             holder.tanggal.setText(finalDay);
        }catch (Exception e){
            e.printStackTrace();
        }

        Glide.with(context).load("http://image.tmdb.org/t/p/w92/"+mList.get(position).getPosterPath()).into(holder.gambar);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetailSearchFilmFragment detailSearchFilmFragment = new DetailSearchFilmFragment();
                SearchFilmModel resultsItem = new SearchFilmModel();

                resultsItem.setPosterPath(mList.get(position).getPosterPath());
                resultsItem.setOriginalTitle(mList.get(position).getOriginalTitle());
                resultsItem.setOverview(mList.get(position).getOverview());
                resultsItem.setReleaseDate(mList.get(position).getReleaseDate());

                Bundle bundle = new Bundle();
                bundle.putParcelable(DetailSearchFilmFragment.EXTRA_DETAIL_FILM, resultsItem);
                detailSearchFilmFragment.setArguments(bundle);

                fragmentManager.beginTransaction()
                        .replace(R.id.frame_container, detailSearchFilmFragment, detailSearchFilmFragment.getClass().getSimpleName())
                        .addToBackStack(detailSearchFilmFragment.getClass().getSimpleName())
                        .commit();

            }
        });
    }

    @Override
    public int getItemCount() {
        return mList.size();
    }

    public class MyHolder extends RecyclerView.ViewHolder {
        TextView judul, overview, tanggal;
        ImageView gambar;

        public MyHolder(View v) {
            super(v);
            judul = v.findViewById(R.id.tv_search_judul_film);
            overview = v.findViewById(R.id.tv_search_overview);
            tanggal = v.findViewById(R.id.tv_search_tanggal_film);
            gambar = v.findViewById(R.id.iv_search_film);


        }

    }
}
