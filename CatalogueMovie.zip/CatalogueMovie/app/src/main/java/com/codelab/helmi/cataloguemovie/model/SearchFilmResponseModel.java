package com.codelab.helmi.cataloguemovie.model;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class SearchFilmResponseModel {

	@SerializedName("page")
	private int page;

	@SerializedName("total_pages")
	private int totalPages;

	@SerializedName("results")
	private List<SearchFilmModel> results;

	@SerializedName("total_results")
	private int totalResults;


	public List<SearchFilmModel> getResults(){
		return results;
	}


	@Override
 	public String toString(){
		return 
			"SearchFilmResponseModel{" +
			"page = '" + page + '\'' + 
			",total_pages = '" + totalPages + '\'' + 
			",results = '" + results + '\'' + 
			",total_results = '" + totalResults + '\'' + 
			"}";
		}
}