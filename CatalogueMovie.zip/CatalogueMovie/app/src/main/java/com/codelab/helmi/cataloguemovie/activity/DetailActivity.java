package com.codelab.helmi.cataloguemovie.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.codelab.helmi.cataloguemovie.R;
import com.codelab.helmi.cataloguemovie.model.MoviesModel;
import com.codelab.helmi.cataloguemovie.model.MoviesResponseModel;

import butterknife.BindView;
import butterknife.ButterKnife;

public class DetailActivity extends AppCompatActivity {

    public static String EXTRA_DETAIL_FILM = "extra_detail_film";

    @BindView(R.id.iv_detail_film)
    ImageView ivDetailFilm;
    @BindView(R.id.tv_detail_judul)
    TextView tvDetailJudul;
    @BindView(R.id.tv_detail_release_date)
    TextView tvDetailReleaseDate;
    @BindView(R.id.tv_detail_overview)
    TextView tvDetailOverview;

    Bundle bundle;

    MoviesModel resultsItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        ButterKnife.bind(this);
        getSupportActionBar().setTitle(R.string.detail_movie);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        tampilDataDetail();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                supportFinishAfterTransition();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void tampilDataDetail() {
        bundle = getIntent().getExtras();
        resultsItem = bundle.getParcelable(EXTRA_DETAIL_FILM);
        tvDetailJudul.setText(resultsItem.getOriginalTitle());
        tvDetailOverview.setText(resultsItem.getOverview());
        tvDetailReleaseDate.setText(resultsItem.getReleaseDate());
        Glide.with(this).load("http://image.tmdb.org/t/p/w500/" + resultsItem.getPosterPath()).into(ivDetailFilm);
    }
}
