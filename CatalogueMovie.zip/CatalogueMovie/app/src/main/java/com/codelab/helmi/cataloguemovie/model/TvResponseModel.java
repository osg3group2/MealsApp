package com.codelab.helmi.cataloguemovie.model;

import java.util.List;
import com.google.gson.annotations.SerializedName;

public class TvResponseModel{

	@SerializedName("page")
	private int page;

	@SerializedName("total_pages")
	private int totalPages;

	@SerializedName("results")
	private List<TvModel> results;

	@SerializedName("total_results")
	private int totalResults;

	public List<TvModel> getResults(){
		return results;
	}

	@Override
 	public String toString(){
		return 
			"TvResponseModel{" + 
			"page = '" + page + '\'' + 
			",total_pages = '" + totalPages + '\'' + 
			",results = '" + results + '\'' + 
			",total_results = '" + totalResults + '\'' + 
			"}";
		}
}